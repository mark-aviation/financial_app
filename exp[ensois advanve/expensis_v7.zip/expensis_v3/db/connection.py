# db/connection.py — Connection pool + DB config management
#
# 🏛️ Architect: This module owns ALL database connectivity.
#   - Single pool shared across the entire app (no per-request connections)
#   - Config loaded once from JSON, saved back on change
#   - get_connection() is the ONLY way to get a DB connection
#
# 💎 Dev: Replaces the old get_db_connection() that opened a fresh
#   TCP handshake on every single call — the #1 cause of slowness.

import json
import logging
import os
from contextlib import contextmanager

import mysql.connector
from mysql.connector import pooling, Error as MySQLError

from config import (
    DB_CONFIG_FILE,
    DB_DEFAULTS,
    DB_POOL_NAME,
    DB_POOL_SIZE,
    DB_CONNECTION_TIMEOUT,
)

logger = logging.getLogger(__name__)

# Module-level pool — initialized once, shared everywhere
_pool: pooling.MySQLConnectionPool | None = None


# ---------------------------------------------------------------------------
# Config helpers
# ---------------------------------------------------------------------------

def load_db_config() -> dict:
    """Load DB config from JSON file, falling back to defaults."""
    if os.path.exists(DB_CONFIG_FILE):
        try:
            with open(DB_CONFIG_FILE, "r") as f:
                return json.load(f)
        except (json.JSONDecodeError, OSError) as e:
            logger.warning("Could not read db config file: %s — using defaults", e)
    return dict(DB_DEFAULTS)


def save_db_config(config: dict) -> None:
    """Persist DB config to JSON file."""
    try:
        with open(DB_CONFIG_FILE, "w") as f:
            json.dump(config, f, indent=2)
        logger.info("DB config saved.")
    except OSError as e:
        logger.error("Failed to save DB config: %s", e)


# ---------------------------------------------------------------------------
# Pool management
# ---------------------------------------------------------------------------

def init_pool(config: dict | None = None) -> None:
    """
    Initialize (or re-initialize) the connection pool.
    Call once at startup, and again after DB settings change.
    """
    global _pool
    cfg = config or load_db_config()

    # Tear down existing pool gracefully
    if _pool is not None:
        logger.info("Reinitializing DB connection pool...")
        _pool = None

    try:
        _pool = pooling.MySQLConnectionPool(
            pool_name=DB_POOL_NAME,
            pool_size=DB_POOL_SIZE,
            pool_reset_session=True,
            host=cfg["host"],
            port=int(cfg.get("port", 3306)),
            user=cfg["user"],
            password=cfg["password"],
            database=cfg["database"],
            connection_timeout=DB_CONNECTION_TIMEOUT,
        )
        logger.info("DB pool initialized (size=%d, host=%s)", DB_POOL_SIZE, cfg["host"])
    except MySQLError as e:
        logger.error("Failed to initialize DB pool: %s", e)
        _pool = None
        raise


def is_connected() -> bool:
    """Quick non-blocking check — tries to borrow a connection from the pool."""
    try:
        with get_connection() as conn:
            return conn.is_connected()
    except Exception:
        return False


# ---------------------------------------------------------------------------
# Connection context manager — the ONE way to get a connection
# ---------------------------------------------------------------------------

@contextmanager
def get_connection():
    """
    Usage:
        with get_connection() as conn:
            cursor = conn.cursor(dictionary=True)
            cursor.execute(...)

    Automatically returns the connection to the pool on exit.
    Raises RuntimeError if pool is not initialized.
    """
    if _pool is None:
        raise RuntimeError(
            "DB pool is not initialized. Call db.connection.init_pool() at startup."
        )

    conn = None
    try:
        conn = _pool.get_connection()
        yield conn
    except MySQLError as e:
        logger.error("DB error: %s", e)
        raise
    finally:
        if conn is not None:
            try:
                conn.close()  # Returns to pool, does not close TCP connection
            except Exception:
                pass
