# services/purchase_advisor.py — Purchase decision engine
#
# Combines salary, loans, credit cards, wallet balances,
# monthly budget, and project commitments into a single
# PurchaseAnalysis verdict for any proposed purchase.

import logging
from dataclasses import dataclass, field
from datetime import datetime

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Output data structures
# ---------------------------------------------------------------------------

@dataclass
class PaymentOption:
    method: str          # "cash" | "credit" | "loan"
    feasible: bool
    label: str           # e.g. "✅ Cash purchase — affordable"
    detail: str          # full explanation
    monthly_impact: float = 0.0   # extra monthly obligation if chosen


@dataclass
class PurchaseAnalysis:
    # Inputs
    item_name:    str
    price:        float
    wallet:       str

    # Financial snapshot
    salary:                   float = 0.0
    avg_monthly_expenses:     float = 0.0
    total_loan_payments:      float = 0.0
    total_min_card_payments:  float = 0.0
    true_disposable_income:   float = 0.0

    # Wallet snapshot
    wallet_balance:       float = 0.0
    project_committed:    float = 0.0
    free_wallet_balance:  float = 0.0
    buying_power_pct:     float = 0.0

    # Monthly budget
    monthly_budget:       float = 0.0
    budget_used:          float = 0.0
    budget_remaining:     float = 0.0

    # Overall verdict
    verdict:        str = "no"        # "yes" | "caution" | "no"
    verdict_reason: str = ""

    # Payment options (cash / credit / loan)
    payment_options: list[PaymentOption] = field(default_factory=list)

    # Projects that would be at risk
    at_risk_projects: list[str] = field(default_factory=list)


# ---------------------------------------------------------------------------
# Main analysis function
# ---------------------------------------------------------------------------

def analyse_purchase(
    user_id: int,
    item_name: str,
    price: float,
    wallet: str,
    loan_months: int = 12,    # for loan option calculation
) -> PurchaseAnalysis:
    """
    Run the full purchase analysis. Returns a PurchaseAnalysis dataclass.
    loan_months: assumed repayment period if the loan option is chosen.
    """
    from models.financial_profile import get_salary
    from models.loan import get_loans, get_total_monthly_loan_payments
    from models.credit_card import get_credit_cards, get_total_minimum_payments
    from models.budget import get_latest_budget
    from services.analytics_service import get_wallet_balances, get_summary_totals
    from services.budget_service import get_project_budget_summary

    result = PurchaseAnalysis(item_name=item_name, price=price, wallet=wallet)

    # ── 1. Salary & obligations ──────────────────────────────────────────
    result.salary                  = get_salary(user_id)
    result.total_loan_payments     = get_total_monthly_loan_payments(user_id)
    result.total_min_card_payments = get_total_minimum_payments(user_id)

    # Average monthly expenses (last 3 months from all-time data)
    try:
        totals = get_summary_totals(user_id, "This Month")
        result.avg_monthly_expenses = totals.get("total_out", 0.0)
    except Exception:
        result.avg_monthly_expenses = 0.0

    result.true_disposable_income = (
        result.salary
        - result.avg_monthly_expenses
        - result.total_loan_payments
        - result.total_min_card_payments
    )

    # ── 2. Wallet balance ────────────────────────────────────────────────
    try:
        wallet_list = get_wallet_balances(user_id, "All Time")
        wallet_map  = {w["wallet"]: w["balance"] for w in wallet_list}
        result.wallet_balance = wallet_map.get(wallet, 0.0)
    except Exception:
        result.wallet_balance = 0.0

    # ── 3. Project commitments from chosen wallet ────────────────────────
    try:
        budget_summary = get_project_budget_summary(user_id)
        committed = sum(
            ar.allocated_cost
            for ar in budget_summary.allocation_rows
            if ar.wallet_name == wallet
        )
        result.project_committed = committed

        # Projects that would be put at risk by this purchase
        new_balance = result.wallet_balance - price
        for ar in budget_summary.allocation_rows:
            if ar.wallet_name == wallet:
                if new_balance < ar.allocated_cost:
                    if ar.project_name not in result.at_risk_projects:
                        result.at_risk_projects.append(ar.project_name)
    except Exception:
        result.project_committed = 0.0

    result.free_wallet_balance = max(0.0, result.wallet_balance - result.project_committed)
    result.buying_power_pct    = (
        (result.free_wallet_balance / price * 100) if price > 0 else 0.0
    )

    # ── 4. Monthly budget ────────────────────────────────────────────────
    try:
        result.monthly_budget    = get_latest_budget(user_id) or 0.0
        result.budget_used       = result.avg_monthly_expenses
        result.budget_remaining  = max(0.0, result.monthly_budget - result.budget_used)
    except Exception:
        pass

    # ── 5. Overall verdict ───────────────────────────────────────────────
    shortfall = price - result.free_wallet_balance

    if result.free_wallet_balance >= price and not result.at_risk_projects:
        result.verdict        = "yes"
        result.verdict_reason = (
            f"Your free wallet balance (₱{result.free_wallet_balance:,.2f}) "
            f"covers this purchase with ₱{result.free_wallet_balance - price:,.2f} to spare."
        )
    elif result.free_wallet_balance >= price and result.at_risk_projects:
        result.verdict        = "caution"
        result.verdict_reason = (
            f"You can cover this purchase but it will put "
            f"{len(result.at_risk_projects)} project(s) at risk: "
            f"{', '.join(result.at_risk_projects)}."
        )
    else:
        result.verdict        = "no"
        result.verdict_reason = (
            f"Insufficient free balance. You are ₱{shortfall:,.2f} short "
            f"after accounting for project commitments."
        )

    # ── 6. Payment options ───────────────────────────────────────────────
    result.payment_options = _build_payment_options(
        user_id, price, wallet, result, loan_months,
    )

    return result


# ---------------------------------------------------------------------------
# Payment option builders
# ---------------------------------------------------------------------------

def _build_payment_options(
    user_id: int,
    price: float,
    wallet: str,
    snapshot: PurchaseAnalysis,
    loan_months: int,
) -> list[PaymentOption]:
    options = []

    # ── Cash ────────────────────────────────────────────────────────────
    if snapshot.free_wallet_balance >= price:
        after = snapshot.free_wallet_balance - price
        options.append(PaymentOption(
            method="cash", feasible=True,
            label="✅ Cash — affordable",
            detail=(f"Pay ₱{price:,.2f} from {wallet}. "
                    f"Remaining free balance: ₱{after:,.2f}."),
            monthly_impact=0.0,
        ))
    else:
        shortfall = price - snapshot.free_wallet_balance
        options.append(PaymentOption(
            method="cash", feasible=False,
            label="❌ Cash — not enough free balance",
            detail=(f"You need ₱{shortfall:,.2f} more in free balance. "
                    f"Current free balance: ₱{snapshot.free_wallet_balance:,.2f}."),
            monthly_impact=0.0,
        ))

    # ── Credit card ──────────────────────────────────────────────────────
    try:
        from models.credit_card import get_credit_cards
        cards = get_credit_cards(user_id)
        if cards:
            best_card = max(cards, key=lambda c: c.available_credit)
            if best_card.available_credit >= price:
                extra_min = price * (best_card.minimum_payment_pct / 100)
                new_disp  = snapshot.true_disposable_income - extra_min
                feasible  = new_disp >= 0
                options.append(PaymentOption(
                    method="credit", feasible=feasible,
                    label=f"{'✅' if feasible else '⚠️'} Credit — {best_card.card_name}",
                    detail=(
                        f"Use {best_card.card_name} ({best_card.bank}). "
                        f"Available credit: ₱{best_card.available_credit:,.2f}. "
                        f"Next month minimum payment increases by ₱{extra_min:,.2f}. "
                        f"New disposable income: ₱{new_disp:,.2f}/mo."
                    ),
                    monthly_impact=extra_min,
                ))
            else:
                options.append(PaymentOption(
                    method="credit", feasible=False,
                    label="❌ Credit — insufficient limit",
                    detail=(f"Best available credit: ₱{best_card.available_credit:,.2f} "
                            f"on {best_card.card_name}. Need ₱{price:,.2f}."),
                    monthly_impact=0.0,
                ))
        else:
            options.append(PaymentOption(
                method="credit", feasible=False,
                label="— No credit cards on file",
                detail="Add a credit card in Settings → Financial Profile.",
                monthly_impact=0.0,
            ))
    except Exception as e:
        logger.error("Credit option failed: %s", e)

    # ── Loan ─────────────────────────────────────────────────────────────
    if loan_months > 0:
        monthly_payment = price / loan_months
        new_disp        = snapshot.true_disposable_income - monthly_payment
        feasible        = new_disp >= 0
        options.append(PaymentOption(
            method="loan", feasible=feasible,
            label=f"{'✅' if feasible else '⚠️'} Loan over {loan_months} months",
            detail=(
                f"Estimated monthly payment: ₱{monthly_payment:,.2f}/mo for {loan_months} months. "
                f"Remaining disposable income: ₱{new_disp:,.2f}/mo. "
                f"{'Affordable.' if feasible else 'WARNING: exceeds your disposable income.'}"
            ),
            monthly_impact=monthly_payment,
        ))

    return options
