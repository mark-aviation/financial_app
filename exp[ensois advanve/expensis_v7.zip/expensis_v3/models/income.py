# models/income.py — Income CRUD operations
#
# 💎 Dev: Mirrors the expense model structure for consistency.

import logging
from datetime import datetime

import pandas as pd

from db import get_connection

logger = logging.getLogger(__name__)


def get_income_df(user_id: int, filter_mode: str = "This Month") -> pd.DataFrame:
    try:
        with get_connection() as conn:
            df = pd.read_sql(
                "SELECT id, date, source, amount FROM income WHERE user_id = %s ORDER BY date DESC",
                conn,
                params=(user_id,),
            )

        if df.empty:
            return df

        df.rename(columns={
            "id": "ID", "date": "Date", "source": "Source", "amount": "Amount",
        }, inplace=True)

        df["Date"] = pd.to_datetime(df["Date"])
        return _apply_date_filter(df, filter_mode)

    except Exception as e:
        logger.error("get_income_df failed: %s", e)
        return pd.DataFrame()


def add_income(user_id: int, date: str, source: str, amount: float) -> bool:
    try:
        with get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(
                "INSERT INTO income (user_id, date, source, amount) VALUES (%s, %s, %s, %s)",
                (user_id, date, source, amount),
            )
            conn.commit()
            cursor.close()
        return True
    except Exception as e:
        logger.error("add_income failed: %s", e)
        return False


def update_income(income_id: int, date: str, source: str, amount: float) -> bool:
    try:
        with get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(
                "UPDATE income SET date=%s, source=%s, amount=%s WHERE id=%s",
                (date, source, amount, income_id),
            )
            conn.commit()
            cursor.close()
        return True
    except Exception as e:
        logger.error("update_income failed: %s", e)
        return False


def delete_income(income_id: int) -> bool:
    try:
        with get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("DELETE FROM income WHERE id=%s", (income_id,))
            conn.commit()
            cursor.close()
        return True
    except Exception as e:
        logger.error("delete_income failed: %s", e)
        return False


def get_wallet_list(user_id: int) -> list[str]:
    """Return distinct income sources (wallets) for this user."""
    try:
        with get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(
                "SELECT DISTINCT source FROM income WHERE user_id = %s", (user_id,)
            )
            sources = [r[0] for r in cursor.fetchall()]
            cursor.close()
        return sorted(sources) if sources else ["Cash"]
    except Exception as e:
        logger.error("get_wallet_list failed: %s", e)
        return ["Cash"]


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _apply_date_filter(df: pd.DataFrame, mode: str) -> pd.DataFrame:
    now = datetime.now()
    if mode == "This Month":
        return df[(df["Date"].dt.year == now.year) & (df["Date"].dt.month == now.month)]
    elif mode == "This Year":
        return df[df["Date"].dt.year == now.year]
    return df
