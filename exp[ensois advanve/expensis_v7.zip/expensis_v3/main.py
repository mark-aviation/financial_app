# main.py — Entry point
# 💎 Dev: 15 lines. Nothing else belongs here.

import logging
from config import LOG_LEVEL
from db.connection import init_pool

logging.basicConfig(
    level=getattr(logging, LOG_LEVEL, logging.WARNING),
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)

if __name__ == "__main__":
    # Startup import diagnostics
    print("--- Expensis startup diagnostics ---")
    for mod, names in [
        ("services.analytics_service", ["get_wallet_balances","get_pie_data_filtered","get_cashflow_data_filtered"]),
        ("services.time_filter",        ["TimeFilter","MODE_ALL"]),
        ("models.expense",              ["get_expenses_df_filtered","get_summary_stats"]),
    ]:
        try:
            m = __import__(mod, fromlist=names)
            for n in names: getattr(m, n)
            print(f"[OK] {mod}")
        except Exception as e:
            print(f"[FAIL] {mod}: {e}")
    print("--- end diagnostics ---")

    # Initialize connection pool before any UI loads
    try:
        init_pool()
    except Exception:
        pass  # Pool failure is shown in the UI via server status indicator

    from ui.app import App
    app = App()
    app.mainloop()
